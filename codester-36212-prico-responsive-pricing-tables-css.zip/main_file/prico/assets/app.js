/*
    Author: Availablecoder
    Version: 1.0
    Date Puplished: 08/03/2022
*/


// Getting Elements
const menuToggler = document.querySelector(".toggler");
const shapeOption = document.getElementById("shapeOption");
const ribbonOption = document.getElementById("ribbonOption");
const animationOption = document.getElementById("animationOption");
const allOptions = [shapeOption, ribbonOption, animationOption];
const toggledItem = document.querySelector(".toggle-field");
const pricingFields = document.querySelectorAll(".pricing-table-field");

// Menu Button
menuToggler.onclick = function () {
  this.classList.toggle("toggle-activate");
  toggledItem.style.display = "flex";
  toggledItem.style.overflow = "hidden";
  let usedHeight = toggledItem.clientHeight + "px";
  if (this.classList.contains("toggle-activate")) {
    toggledItem.animate([
      {height: "0px", padding: "0"},
      {height: usedHeight, padding: "10px 0"},
    ], {
      duration: 300
    });
    setTimeout(function() {
      toggledItem.style.display = "flex";
    }, 300);
  } else {
    toggledItem.animate([
      {height: usedHeight, padding: "10px 0"},
      {height: "0px", padding: "0px 0"},
    ], {
      duration: 300
    });
    setTimeout(function() {
      toggledItem.style.display = "none";
    }, 300);
  }
}

// Toggling Selecting
allOptions.forEach(e => {
  e.onclick = (element) => {
    allOptions.forEach(e => {
      if (e !== element.currentTarget) {
        e.classList.remove("showing");
      }
    });
    e.classList.toggle("showing");
    toggledItem.style.overflow = "visible";
  };
});

// Activating Classes of Select boxes
function links(elements, parent) {
  elements.forEach(e => {
    e.onclick = function () {
      parent.firstElementChild.innerHTML = e.innerHTML;
      for (let i = 1; i <= 5; i++) {
        pricingFields.forEach(e => e.classList.remove(`prico-${parent.firstElementChild.innerHTML.toLowerCase().slice(0, -1) + i}`));
      }
      pricingFields.forEach(e => e.classList.add(`prico-${parent.firstElementChild.innerHTML.toLowerCase()}`));
    }
  })
};
links(Array.from(document.querySelectorAll("#ribbonOption ul li")), ribbonOption);
links(Array.from(document.querySelectorAll("#animationOption ul li")), animationOption);

// Color Switcher
document.querySelector(".switcher-field .icon").onclick = function(e) {
  this.parentElement.classList.toggle("sliding");
}
const colorButtons = document.querySelectorAll(".switcher-field .colors > div");
colorButtons.forEach(e => {
  e.style.backgroundColor = e.dataset.color;
  e.addEventListener('click', function() {
    colorButtons.forEach(e => e.classList.remove("active"));
    e.classList.add("active");
    document.documentElement.style.setProperty('--prico-color', e.dataset.color);
  });
});


