/*=========================================

Template Name: Parekh - Digital Agency Template
Author: Design Your Buisness
Version: 1.0
Design and Developed by: Design Your Buisness

=========================================*/


$(document).ready(function() {

	/*=============================
                PRELOADER JS
        ==============================*/

	setTimeout(()=> {
		$('#preloader').addClass('d-none');
	},2500);

	/*=============================
             FIXED HEADER AFTER SCROLL JS
        ==============================*/

	$(window).scroll(function() {
		let scrollTop = $(window).scrollTop();
		let windowWidth = $(window).width();
		if(scrollTop > 30) {
			$('.header-section').addClass('scrolled-view');
		} else {
			$('.header-section').removeClass('scrolled-view');
		}
	});

	/*=============================
                BACK TO TOP
        ==============================*/

	$(window).scroll(function() {
		let scrollTop = $(window).scrollTop();
		if(scrollTop > 300) {
			$('#scroll-to-top').removeClass('d-none');
		} else {
			$('#scroll-to-top').addClass('d-none');
		}
	});	

	/*===================================
           BANNER Slider
     ====================================*/

    $(".carousel-single-item").owlCarousel({
        loop: true,
        center: true,
        nav: false,
        dots: true,
        autoplay: true,
        autoplayHoverPause: true,
        autoplayTimeout: 2000,
        // navText: ["<i class='fa fa-angle-left'></i>", "<i class='fa fa-angle-right'></i>"],
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 1
            },
            1000: {
                items: 1
            }
        }
    });


	/*=============================
                OUR WORK SLIDER
        ==============================*/

	$('.our-projects-carousel').owlCarousel({
		autoplay: true,
		autoplayTimeout: 4000,
  		smartSpeed: 800,
	    loop:true,
	    margin:10,
	    responsiveClass:true,
	    nav:false,
	    dots:true,
	    responsive:{
	        0:{
	            items:1,
	        },
	        600:{
	            items:2,
	        },
	        1000:{
	            items:2,
	        }
	    }
	});

	
	/*=============================
                TESTIMONIALS SLIDER
        ==============================*/
        
	$('.testimonials-carousel').owlCarousel({
		autoplay: true,
	    loop:true,
	    margin:10,
	    responsiveClass:true,
	    dots: true,
	    autoplayTimeout: 4000,
  		smartSpeed: 800,
	    responsive:{
	        0:{
	            items:1,
	        },
	        600:{
	            items:2,
	        },
	        1000:{
	            items:3,
	        }
	    }
	});

	 


})

