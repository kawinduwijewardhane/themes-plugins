$(function() {
    
    // About link
    
    $("#about-section-link").on('click', function() {
        var position = $("#about-section").offset().top - 70;
        $("HTML, BODY").animate({
            scrollTop: position
        }, 1000);
    });

    // Services link

    $("#services-section-link").on('click', function() {
        var position = $("#services-section").offset().top - 70;
        $("HTML, BODY").animate({
            scrollTop: position
        }, 1000);
    });

    // Project link

    $("#project-section-link").on('click', function() {
        var position = $("#project-section").offset().top - 70;
        $("HTML, BODY").animate({
            scrollTop: position
        }, 1000);
    });

    // Team link

    $("#team-section-link").on('click', function() {
        var position = $("#team-section").offset().top - 70;
        $("HTML, BODY").animate({
            scrollTop: position
        }, 1000);
    });

    // Testimonial link

    $("#testimonial-section-link").on('click', function() {
        var position = $("#testimonial-section").offset().top - 70;
        $("HTML, BODY").animate({
            scrollTop: position
        }, 1000);
    });

    // Contact link

    $("#contact-section-link").on('click', function() {
        var position = $("#contact-section").offset().top - 70;
        $("HTML, BODY").animate({
            scrollTop: position
        }, 1000);
    });


    // ________________ x  Show active link

    $(window).scroll(function() {
        let scrollTop = $(window).scrollTop();
        console.log('scrollTop',scrollTop);
        var hero_position = $("#hero-section").offset().top;
        var about_position = $("#about-section").offset().top-100;
        var services_position = $("#services-section").offset().top-100;
        var project_position = $("#project-section").offset().top-100;
        var team_position = $("#team-section").offset().top-100;
        var testimonial_position = $("#testimonial-section").offset().top-100;
        var contact_position = $("#contact-section").offset().top-100;
        

        if(scrollTop < about_position) {
            $('.navbar-nav .nav-link').removeClass('active');
            $('#home-section-link').addClass('active');
        } else if(scrollTop > hero_position && scrollTop < services_position) {
            $('.navbar-nav .nav-link').removeClass('active');
            $('#about-section-link').addClass('active');
        } else if(scrollTop > services_position && scrollTop < project_position) {
            $('.navbar-nav .nav-link').removeClass('active');
            $('#services-section-link').addClass('active');
        } else if(scrollTop > project_position && scrollTop < team_position) {
            $('.navbar-nav .nav-link').removeClass('active');
            $('#project-section-link').addClass('active');
        } else if(scrollTop > team_position && scrollTop < testimonial_position) {
            $('.navbar-nav .nav-link').removeClass('active');
            $('#team-section-link').addClass('active');
        } else if(scrollTop > testimonial_position && scrollTop < contact_position) {
            $('.navbar-nav .nav-link').removeClass('active');
            $('#testimonial-section-link').addClass('active');
        } else if(scrollTop > contact_position) {
            $('.navbar-nav .nav-link').removeClass('active');
            $('#contact-section-link').addClass('active');
        }


    }); 

     // ________________ x  Collpse menu on click link for mobile version

     $('.nav-link').click(function() {

        let window_width = $(window).width();
        if(window_width < 600) {
            $('#navbarSupportedContent').removeClass('show');
        }

    });



});