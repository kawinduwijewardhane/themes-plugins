import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './common/header/header.component';
import { FooterComponent } from './common/footer/footer.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MaterialModule } from './app-material.module';
import { LeftbarComponent } from './common/leftbar/leftbar.component';
import { NewcustomerComponent } from './components/newcustomer/newcustomer.component';
import { AllcustomersComponent } from './components/allcustomers/allcustomers.component';
import { NewstaffComponent } from './components/newstaff/newstaff.component';
import { AllstaffsComponent } from './components/allstaffs/allstaffs.component';
import { ServicesComponent } from './components/services/services.component';
import { InventoryComponent } from './components/inventory/inventory.component';
import { BillingComponent } from './components/billing/billing.component';
import { BreadcrumbComponent } from './common/breadcrumb/breadcrumb.component';
import { NewserviceComponent } from './components/newservice/newservice.component';
import { AllbillingsComponent } from './components/allbillings/allbillings.component';
import { PrinttableComponent } from './components/printtable/printtable.component';
import { EditserviceComponent } from './components/editservice/editservice.component';
import { EditstaffComponent } from './components/editstaff/editstaff.component';
import { EditcustomerComponent } from './components/editcustomer/editcustomer.component';
import { SummaryComponent } from './components/summary/summary.component';
import { NewproductComponent } from './components/newproduct/newproduct.component';
import { AllInventoryComponent } from './components/allinventory/all-inventory.component';
import { EditProductComponent } from './components/editproduct/editproduct.component';
import { EditBillingComponent } from './components/editbill/editbill.component';
import { OrderHistoryComponent } from './components/orderhistory/orderhistory.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    LeftbarComponent,
    NewcustomerComponent,
    AllcustomersComponent,
    NewstaffComponent,
    AllstaffsComponent,
    ServicesComponent,
    InventoryComponent,
    BillingComponent,
    BreadcrumbComponent,
    NewserviceComponent,
    AllbillingsComponent,
    PrinttableComponent,
    EditserviceComponent,
    EditstaffComponent,
    EditcustomerComponent,
    SummaryComponent,
    NewproductComponent,
    AllInventoryComponent,
    EditProductComponent,
    EditBillingComponent,
    OrderHistoryComponent 
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MaterialModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
