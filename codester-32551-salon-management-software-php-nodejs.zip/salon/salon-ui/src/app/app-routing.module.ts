import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { NewcustomerComponent } from './components/newcustomer/newcustomer.component';
import { AllcustomersComponent } from './components/allcustomers/allcustomers.component';
import { NewstaffComponent } from './components/newstaff/newstaff.component';
import { AllstaffsComponent } from './components/allstaffs/allstaffs.component';
import { ServicesComponent } from './components/services/services.component';
import { BillingComponent } from './components/billing/billing.component';
import { NewserviceComponent } from './components/newservice/newservice.component';
import { AllbillingsComponent } from './components/allbillings/allbillings.component';
import { PrinttableComponent } from './components/printtable/printtable.component';
import { EditserviceComponent } from './components/editservice/editservice.component';
import { EditstaffComponent } from './components/editstaff/editstaff.component';
import { EditcustomerComponent } from './components/editcustomer/editcustomer.component';
import { SummaryComponent } from './components/summary/summary.component';
import { NewproductComponent } from './components/newproduct/newproduct.component';
import { EditProductComponent } from './components/editproduct/editproduct.component';
import { AllInventoryComponent } from './components/allinventory/all-inventory.component';
import { EditBillingComponent } from './components/editbill/editbill.component';
import { OrderHistoryComponent } from './components/orderhistory/orderhistory.component';

const routes: Routes = [
  { path: '', component: NewcustomerComponent },
  { path: 'customers', component: AllcustomersComponent },
  { path: 'addstaff', component: NewstaffComponent },
  { path: 'allstaffs', component: AllstaffsComponent },
  { path: 'services', component: ServicesComponent },
  { path: 'billing', component: BillingComponent },
  { path: 'addservice', component: NewserviceComponent },
  { path: 'addproduct', component: NewproductComponent },
  { path: 'allbills', component: AllbillingsComponent },
  { path: 'printtable', component: PrinttableComponent },
  { path: 'service/:id', component: EditserviceComponent },
  { path: 'product/:id', component: EditProductComponent },
  { path: 'staff/:id', component: EditstaffComponent },
  { path: 'customer/:id', component: EditcustomerComponent },
  { path: 'summary', component: SummaryComponent },
  { path: 'inventory', component: AllInventoryComponent },
  { path: 'bill/:id', component: EditBillingComponent },
  { path: 'orderhistory', component: OrderHistoryComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
