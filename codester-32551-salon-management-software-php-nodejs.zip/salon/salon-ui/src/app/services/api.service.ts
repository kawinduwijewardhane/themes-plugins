import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class ApiService {

  baseUrl = "http://localhost:8888/salon-backend/"; //Replace this URL with yours
  constructor(private http: HttpClient) { }

  registerCustomer(data){
    return this.http.post(this.baseUrl+'add/customer', data);
  }

  registerStaff(data){
    return this.http.post(this.baseUrl+'add/staff', data);
  }

  addBill(data){
    return this.http.post(this.baseUrl+'add/bill', data);
  }

  addService(data){
    return this.http.post(this.baseUrl+'add/service', data);
  }

  addProductToInventory(data){
    return this.http.post(this.baseUrl+'add/product', data);
  }

  searchCustomer(data){
    return this.http.post(this.baseUrl+'search/customer', data);
  }

  searchStaff(data){
    return this.http.post(this.baseUrl+'search/staff', data);
  }

  searchService(data){
    return this.http.post(this.baseUrl+'search/service', data);
  }

  getAllCustomers(){
    return this.http.get(this.baseUrl+'get/customers');
  }

  getAllProducts(){
    return this.http.get(this.baseUrl+'get/products');
  }

  getCustomersRangeWise(size,range){
    return this.http.get(this.baseUrl+'get/customers/'+size+'/'+range);
  }

  getAllStaffs(){
    return this.http.get(this.baseUrl+'get/staffs');
  }

  getAllServices(){
    return this.http.get(this.baseUrl+'get/services');
  }

  getSummary(){
    return this.http.get(this.baseUrl+'get/summary');
  }

  getSummaryByDate(month, year){
    return this.http.get(this.baseUrl+'get/summary/'+month+'/'+year);
  }

  getServiceById(id){
    return this.http.get(this.baseUrl+'get/service/'+id);
  }

  getStaffById(id){
    return this.http.get(this.baseUrl+'get/staff/'+id);
  }

  getCustomerById(id){
    return this.http.get(this.baseUrl+'get/customer/'+id);
  }

  getProductById(id){
    return this.http.get(this.baseUrl+'get/product/'+id);
  }

  getAllBilling(){
    return this.http.get(this.baseUrl+'get/billings');
  }

  getBillById(id){
    return this.http.get(this.baseUrl+'get/bill/'+id);
  }

  getOrderHisoryByCustomerId(id){
    return this.http.get(this.baseUrl+'get/orderhistory/'+id);
  }

  editService(data){
    return this.http.put(this.baseUrl+'edit/service', data);
  }

  editCustomer(data){
    return this.http.put(this.baseUrl+'edit/customer', data);
  }

  editStaff(data){
    return this.http.put(this.baseUrl+'edit/staff', data);
  }

  editProduct(data){
    return this.http.put(this.baseUrl+'edit/product', data);
  }

  editBill(data){
    return this.http.put(this.baseUrl+'edit/bill', data);
  }

  deleteCustomer(id){
    return this.http.delete(this.baseUrl+'delete/customer/'+id);
  }

  deleteStaff(id){
    return this.http.delete(this.baseUrl+'delete/staff/'+id);
  }

  deleteService(id){
    return this.http.delete(this.baseUrl+'delete/service/'+id);
  }

  deleteProduct(id){
    return this.http.delete(this.baseUrl+'delete/product/'+id);
  }

  deleteBill(id){
    return this.http.delete(this.baseUrl+'delete/bill/'+id);
  }

  printBill(billId){
    return this.http.get(this.baseUrl+'print/'+billId);
  }
}
