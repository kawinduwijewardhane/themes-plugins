import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, Validators, NgForm, FormGroupDirective } from '@angular/forms';
import { ApiService } from './../../services/api.service';

import {Router, ActivatedRoute} from '@angular/router';

import {
  MatSnackBar,
  MatSnackBarHorizontalPosition,
  MatSnackBarVerticalPosition,
} from '@angular/material/snack-bar';

@Component({
  selector: 'app-editservice',
  templateUrl: './editservice.component.html',
  styleUrls: ['./editservice.component.scss']
})
export class EditserviceComponent implements OnInit {

  type = "Services";
  title = "Edit";

  formSubmitted = true;

  @ViewChild('servForm', {static: false}) ngForm;

  serviceForm = this.fb.group({
    name: ['', Validators.required],
    price: ['', Validators.required]
  });

  horizontalPosition: MatSnackBarHorizontalPosition = 'end';
  verticalPosition: MatSnackBarVerticalPosition = 'top';

  constructor(public fb: FormBuilder, private router:Router, private route: ActivatedRoute, public apiService: ApiService, private _snackBar: MatSnackBar) { }

  ngOnInit() {
    this.apiService.getServiceById(this.route.snapshot.params.id).subscribe(res=>{
      this.serviceForm.controls['name'].setValue(res['data']['name']);
      this.serviceForm.controls['price'].setValue(res['data']['price']);
    });
  }

  onSubmit(){
    this.formSubmitted = false;
    if (this.serviceForm.invalid) {
      return;
    }
    this.formSubmitted = true;
    let serviceData = {
      "name": this.serviceForm.value['name'],
      "price": this.serviceForm.value['price'],
      "id": this.route.snapshot.params.id
    }
    
    this.apiService.editService(serviceData).subscribe(
      (res) => {
        this.ngForm.resetForm();
        this._snackBar.open(res['message'], 'Ok', {
          duration: 2000,
          horizontalPosition: this.horizontalPosition,
          verticalPosition: this.verticalPosition,
        });

        this.router.navigate(['/services']);
      },
      (err) => {
        this._snackBar.open('Some error occurred, please try again', 'Ok', {
          duration: 2000,
          horizontalPosition: this.horizontalPosition,
          verticalPosition: this.verticalPosition,
        });
      }
    );
  }

}
