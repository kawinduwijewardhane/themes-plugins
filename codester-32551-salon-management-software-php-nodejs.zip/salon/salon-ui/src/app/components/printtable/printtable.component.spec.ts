import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PrinttableComponent } from './printtable.component';

describe('PrinttableComponent', () => {
  let component: PrinttableComponent;
  let fixture: ComponentFixture<PrinttableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PrinttableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PrinttableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
