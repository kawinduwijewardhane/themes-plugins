import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-printtable',
  templateUrl: './printtable.component.html',
  styleUrls: ['./printtable.component.scss']
})
export class PrinttableComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  
  }

}
