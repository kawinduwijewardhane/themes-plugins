import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AllstaffsComponent } from './allstaffs.component';

describe('AllstaffsComponent', () => {
  let component: AllstaffsComponent;
  let fixture: ComponentFixture<AllstaffsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AllstaffsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AllstaffsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
