import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, Validators, NgForm, FormGroupDirective } from '@angular/forms';
import { ApiService } from './../../services/api.service';
import {
  MatSnackBar,
  MatSnackBarHorizontalPosition,
  MatSnackBarVerticalPosition,
} from '@angular/material/snack-bar';
@Component({
  selector: 'app-newproduct',
  templateUrl: './newproduct.component.html',
  styleUrls: ['./newproduct.component.scss']
})
export class NewproductComponent implements OnInit {

  type = "Products";
  title = "Add a new one";

  formSubmitted = true;

  @ViewChild('servForm', {static: false}) ngForm;

  serviceForm = this.fb.group({
    product_name: ['', Validators.required],
    price: ['', Validators.required],
    quantity: ['', Validators.required]
  });

  horizontalPosition: MatSnackBarHorizontalPosition = 'end';
  verticalPosition: MatSnackBarVerticalPosition = 'top';
  constructor(public fb: FormBuilder, public apiService: ApiService, private _snackBar: MatSnackBar) { }

  ngOnInit() {
  }

  onSubmit(){
    this.formSubmitted = false;
    if (this.serviceForm.invalid) {
      return;
    }
    this.formSubmitted = true;
    
    this.apiService.addProductToInventory(this.serviceForm.value).subscribe(
      (res) => {
        this.ngForm.resetForm();
        this._snackBar.open(res['message'], 'Ok', {
          duration: 2000,
          horizontalPosition: this.horizontalPosition,
          verticalPosition: this.verticalPosition,
        });
      },
      (err) => {
        this._snackBar.open('Some error occurred, please try again', 'Ok', {
          duration: 2000,
          horizontalPosition: this.horizontalPosition,
          verticalPosition: this.verticalPosition,
        });
      }
    );
  }

}