import { Component, OnInit, ViewChild } from '@angular/core';
import {MatTableDataSource} from '@angular/material/table';
import { ApiService } from './../../services/api.service';
import {MatPaginator} from '@angular/material/paginator';

import {
  MatSnackBar,
  MatSnackBarHorizontalPosition,
  MatSnackBarVerticalPosition,
} from '@angular/material/snack-bar';

export interface PeriodicElement {
  serialno: number,
  name: string;
  mobile: number;
  email: string;
  birthday: string;
}

@Component({
  selector: 'app-allcustomers',
  templateUrl: './allcustomers.component.html',
  styleUrls: ['./allcustomers.component.scss']
})

export class AllcustomersComponent implements OnInit {

  type = "Customers";
  title = "All";

  horizontalPosition: MatSnackBarHorizontalPosition = 'end';
  verticalPosition: MatSnackBarVerticalPosition = 'top';

  @ViewChild(MatPaginator, {static: false}) paginator: MatPaginator;

  data: PeriodicElement[] = [
    // {serialno: 1, name: 'Kumar Gautam', mobile: 8210907970, email: 'sajal.suraj@gmail.com', birthday:"09/11/2022"},
    // {serialno: 2, name: 'Sajal Suraj', mobile: 8210907970, email: 'abc@gmail.com', birthday:"09/11/2022"}
  ];

  displayedColumns: string[] = ['serialno', 'name', 'mobile', 'email', 'birthday', 'action'];
  dataSource;
  pageSize = 10;
  itemsToFetchIndex = 0;

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  constructor(public apiService: ApiService, private _snackBar: MatSnackBar) { }

  ngAfterViewInit() {
    
  }

  ngOnInit() {
    let customersData = [];
    this.apiService.getAllCustomers().subscribe(res=>{
      if(res['status']){
        customersData = res['data'];
        let count = 0;
        customersData.forEach((val)=>{
          count++;
          val.serialno = count;
        });
       this.data = customersData;
       this.dataSource = new MatTableDataSource(this.data);
       this.dataSource.paginator = this.paginator;
      }
    },
    err=>{

    });
  }

  pageChangeEvent(eve){
    console.log(eve);
  }

  deleteCustomer(id, name){
    if(confirm("Are you sure to delete "+name+"'s data?")) {
      this.apiService.deleteCustomer(id).subscribe((res)=>{
        this._snackBar.open(res['message'], 'Ok', {
          duration: 2000,
          horizontalPosition: this.horizontalPosition,
          verticalPosition: this.verticalPosition,
        });
        let customersData = [];
        this.apiService.getAllCustomers().subscribe(res=>{
          if(res['status']){
            customersData = res['data'];
            let count = 0;
            customersData.forEach((val)=>{
              count++;
              val.serialno = count;
            });
          this.data = customersData;
          this.dataSource = new MatTableDataSource(this.data);
          this.dataSource.paginator = this.paginator;
          }
        },
        err=>{

        });
      });
    }
  }

}
