import { Component, OnInit, ViewChild } from "@angular/core";
import { ApiService } from "./../../services/api.service";
import { debounceTime, tap, switchMap, finalize } from "rxjs/operators";
import {Router, ActivatedRoute} from '@angular/router';

import {
  FormBuilder,
  Validators,
  NgForm,
  FormGroupDirective,
  FormControlName
} from "@angular/forms";
import * as _ from "underscore";

import {
  MatSnackBar,
  MatSnackBarHorizontalPosition,
  MatSnackBarVerticalPosition
} from "@angular/material/snack-bar";

@Component({
  selector: "app-editbill",
  templateUrl: "./editbill.component.html",
  styleUrls: ["./editbill.component.scss"]
})
export class EditBillingComponent implements OnInit {

    type = "Billing";
    title = "Edit";
    discount:number=0;
    discountApplied = false;

    customers = [];
    staffs = [];
    isLoading = false;
    isLoading1 = false;
    services = [];
    products = [];
    totalAmount = 0;
    finalAmount = 0;
    formSubmitted = true;
    filteredServices = [];
    filteredStaffs = [];
    filteredProducts = [];
    last_bill_id = "";

    @ViewChild("billForm", { static: false }) ngForm;

    billingForm = this.fb.group({
        customerName: ["", Validators.required],
        customerMobile: ["", Validators.required]
    });

    servicesUsed = [];
    productsUsed = [];

    horizontalPosition: MatSnackBarHorizontalPosition = "end";
    verticalPosition: MatSnackBarVerticalPosition = "top";

    constructor(public apiService: ApiService,
        public fb: FormBuilder,
        private _snackBar: MatSnackBar, private router:Router, private route: ActivatedRoute){

    }

    ngOnInit(){
        this.last_bill_id = this.route.snapshot.params.id;
        this.billingForm
        .get("customerMobile")
        .valueChanges.pipe(
            debounceTime(1000), 
            tap(() => {
            this.customers = [];
            this.isLoading = true;
            }),
            switchMap(value =>
            this.apiService
                .searchCustomer({ query: this.billingForm.value["customerMobile"] })
                .pipe(
                finalize(() => {
                    this.isLoading = false;
                })
                )
            )
        )
        .subscribe(data => {
            this.customers = data["data"];
        });

        this.apiService.getBillById(this.route.snapshot.params.id).subscribe((data)=>{
            let res = data['data'];
            this.servicesUsed = res['services'] ? JSON.parse(res['services']) : [];
            this.productsUsed = res['products'] ? JSON.parse(res['products']) : [];
            this.finalAmount = parseInt(res['totalamount']);
            this.discount = parseInt(res['discount_applied']);
            this.totalAmount = this.finalAmount + this.discount;
            this.discountApplied = parseInt(res['discount_applied']) > 0 ? true : false;
            this.billingForm.get('customerMobile').setValue({name:res['name'], mobile: res['mobile']});
            this.billingForm.get('customerName').setValue(res['name']);
            this.apiService.getAllServices().subscribe(res => {
                this.services = res["data"];
            });
        
            this.apiService.getAllStaffs().subscribe(res => {
                this.staffs = res["data"];
            });
        
            this.apiService.getAllProducts().subscribe(res => {
                this.products = res["data"];
            });
        });
    }

    getSelectedCustomer(customer){
        this.billingForm.controls["customerName"].setValue(customer.value.name);
    }

    displayFn(val){
        return val && val.mobile ? val.mobile : "";
    }
    
    displayService(val){
        return val && val.name ? val.name : "";
    }

    calculate() {
        let checkIfValid = true;
        this.totalAmount = 0;
        let checkIfValidProd = true;
    
        if (this.servicesUsed.length) {
          let count = 0;
          this.servicesUsed.forEach(val => {
            count++;
            if (
              _.isEmpty(val.service_used) ||
              val.quantity === null || val.quantity === 0
            ) {
              this._snackBar.open(
                "Please enter all the details for Service " + count,
                "Ok",
                {
                  duration: 2000,
                  horizontalPosition: this.horizontalPosition,
                  verticalPosition: this.verticalPosition
                }
              );
              checkIfValid = false;
            }
          });
        }
    
        if (checkIfValid) {
          this.servicesUsed.forEach(val => {
            this.totalAmount =
              this.totalAmount + parseInt(val.service_used["price"]) * val.quantity;
          });
     
          this.finalAmount = this.totalAmount;
        }
    
        if (this.productsUsed.length) {
          let count = 0;
          this.productsUsed.forEach(val => {
            count++;
            if (
              _.isEmpty(val.product_used) ||
              val.quantity === null || val.quantity === 0
            ) {
              this._snackBar.open(
                "Please enter all the details for Product " + count,
                "Ok",
                {
                  duration: 2000,
                  horizontalPosition: this.horizontalPosition,
                  verticalPosition: this.verticalPosition
                }
              );
              checkIfValidProd = false;
            }
          });
        }
    
        if (checkIfValidProd) {
          this.productsUsed.forEach(val => {
            this.totalAmount =
              this.totalAmount + parseInt(val.product_used["price"]) * val.quantity;
          });
     
          this.finalAmount = this.totalAmount;
        }

        this.finalAmount = this.discountApplied ? this.finalAmount - this.discount : this.finalAmount;
    }

    removeService(idx){
        this.servicesUsed.splice(idx,1);
        this.calculate();
    }
    
    doFilter(name:string) {
        this.filteredServices = this.services.filter((data)=>{
          return data.name.toLowerCase().includes(name.toString().toLowerCase());
        });
    }
    
    doProductFilter(name:string){
        this.filteredProducts = this.products.filter((data)=>{
          return data.product_name.toLowerCase().includes(name.toString().toLowerCase());
        });
    }

    moveNextField(event){
        var form = event.target.form;
        var index = Array.prototype.indexOf.call(form, event.target);
        if(event.target.classList[0] == "quantity"){
          form.elements[index + 2].focus();
        }
        else{
          form.elements[index + 1].focus();
        }
        event.preventDefault();
    }

    doStaffFilter(name:string) {
        this.filteredStaffs = this.staffs.filter((data)=>{
          return data.name.toLowerCase().includes(name.toString().toLowerCase());
        });
    }

    displayProductFn(val){
        return val && val.product_name ? val.product_name : "";
    }

    onSubmit() {
        this.formSubmitted = false;
        if (this.billingForm.invalid) {
          return;
        }
    
        this.calculate();
        let mobileNum = "";
        if(typeof this.billingForm.value["customerMobile"] === "object"){
          mobileNum = this.billingForm.value["customerMobile"].mobile;
        }
        else{
          mobileNum = this.billingForm.value["customerMobile"];
        }
    
        let billForm = {
          customerName: this.billingForm.value["customerName"],
          customerMobile: mobileNum,
          services: JSON.stringify(this.servicesUsed),
          products: JSON.stringify(this.productsUsed),
          discount_applied: this.discount,
          totalamount: this.finalAmount,
          id: this.route.snapshot.params.id
        };
    
        this.apiService.editBill(billForm).subscribe(
          res => {
            this._snackBar.open(res["message"], "Ok", {
              duration: 2000,
              horizontalPosition: this.horizontalPosition,
              verticalPosition: this.verticalPosition
            });
          },
          err => {
            this._snackBar.open("Some error occurred", "Ok", {
              duration: 2000,
              horizontalPosition: this.horizontalPosition,
              verticalPosition: this.verticalPosition
            });
          }
        );
    }

    addService(event) {
        this.servicesUsed.push({
          service_used: {},
          quantity: 0,
          staffId : ""
        });
        var form = event.target.form;
        
        if(form !=  undefined){
          var index = Array.prototype.indexOf.call(form, event.target);
          form.elements[index].focus();
          event.preventDefault();
        }
    }

    printBill() {
        this.apiService.printBill(this.last_bill_id).subscribe(res=>{
          console.log(res);
        },
        error=>{
          this._snackBar.open(error['error']['text'], "Ok", {
            duration: 2000,
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition
          });
        });
    }

    applyDiscount(){
        this.finalAmount = this.totalAmount - this.discount;
        this.discountApplied = true;
    }

    clearDiscount(){
        this.finalAmount = this.totalAmount;
        this.discountApplied = false;
        this.discount = 0;
    }
}