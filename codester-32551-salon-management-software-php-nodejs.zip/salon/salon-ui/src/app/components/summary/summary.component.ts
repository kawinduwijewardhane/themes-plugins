import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/services/api.service';

@Component({
  selector: 'app-summary',
  templateUrl: './summary.component.html',
  styleUrls: ['./summary.component.scss']
})
export class SummaryComponent implements OnInit {

  type = "Summary";
  title = "List";

  selectedYear:any;
  selectedMonth:any;

  m_names = ['January', 'February', 'March', 
  'April', 'May', 'June', 'July', 
  'August', 'September', 'October', 'November', 'December'];

  years = [];

  summaryData:any;
  employeeData = [];

  constructor(public apiService: ApiService) { }

  ngOnInit() {
    let d = new Date();
    let year = d.getFullYear();

    this.selectedYear = year;

    for(var i = 0; i < 3; i++){
      this.years.push(year);
      year = year-1;
    }
   
    this.apiService.getSummary().subscribe(res=>{
      if(res['status']){
        this.summaryData = res['data'];
        this.employeeData = res['emp_data'];
      }
      else{
        let n = this.m_names[d.getMonth()];
        this.summaryData = {
          current_month: n,
          current_year: d.getFullYear(),
          total: 0
        }
      }
    })
  }

  changeYear(event){
    let d = new Date();
    if(this.selectedMonth){
      this.apiService.getSummaryByDate(this.selectedMonth, event.value).subscribe(res=>{
        if(res['status']){
          this.summaryData = res['data'];
          this.employeeData = res['emp_data'];
        }
        else{
          let n = this.m_names[this.selectedMonth-1];
          this.summaryData = {
            current_month: n,
            current_year: event.value,
            total: 0
          }
        }
      });
    }
    else{
      this.apiService.getSummaryByDate(d.getMonth()+1, event.value).subscribe(res=>{
        if(res['status']){
          this.summaryData = res['data'];
          this.employeeData = res['emp_data'];
        }
        else{
          let n = this.m_names[d.getMonth()];
          this.summaryData = {
            current_month: n,
            current_year: event.value,
            total: 0
          }
        }
      });
    }
  }

  changeMonth(event){
    this.apiService.getSummaryByDate(event.value, this.selectedYear).subscribe(res=>{
      if(res['status']){
        this.summaryData = res['data'];
        this.employeeData = res['emp_data'];
      }
      else{
        let n = this.m_names[event.value-1];
        this.summaryData = {
          current_month: n,
          current_year: this.selectedYear,
          total: 0
        }
      }
    });
  }

}
