import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AllbillingsComponent } from './allbillings.component';

describe('AllbillingsComponent', () => {
  let component: AllbillingsComponent;
  let fixture: ComponentFixture<AllbillingsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AllbillingsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AllbillingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
