import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, Validators, NgForm, FormGroupDirective } from '@angular/forms';
import { ApiService } from './../../services/api.service';
import { DatePipe } from '@angular/common';
import {
  MatSnackBar,
  MatSnackBarHorizontalPosition,
  MatSnackBarVerticalPosition,
} from '@angular/material/snack-bar';

@Component({
  selector: 'app-newstaff',
  templateUrl: './newstaff.component.html',
  styleUrls: ['./newstaff.component.scss']
})
export class NewstaffComponent implements OnInit {

  type = "Staffs";
  title = "Add a new staff";

  submitBtnText = "Submit";

  formSubmitted = true;
  isSubmitBtnDisabled = false;
  @ViewChild('staffForm', {static: false}) ngForm;

  signupForm = this.fb.group({
    name: ['', Validators.required],
    address: ['', Validators.required],
    aadhar: ['', [Validators.required, Validators.pattern('[0-9]\\d{11}')]],
    mobile: ['', [Validators.required, Validators.pattern('[5-9]\\d{9}')]]
  });

  horizontalPosition: MatSnackBarHorizontalPosition = 'end';
  verticalPosition: MatSnackBarVerticalPosition = 'top';
  constructor(public fb: FormBuilder, public apiService: ApiService, private _snackBar: MatSnackBar) { }

  ngOnInit() {
  }

  onSubmit() {
    this.formSubmitted = false;
    if (this.signupForm.invalid) {
      return;
    }
    this.formSubmitted = true;
    this.submitBtnText = 'Submitting, please wait...';
    this.isSubmitBtnDisabled = true;
    
    this.apiService.registerStaff(this.signupForm.value).subscribe(
      (res) => {
        this.isSubmitBtnDisabled = false;
        this.submitBtnText = "Submit";
        this.ngForm.resetForm();
        this._snackBar.open(res['message'], 'Ok', {
          duration: 2000,
          horizontalPosition: this.horizontalPosition,
          verticalPosition: this.verticalPosition,
        });
      },
      (err) => {
        this.isSubmitBtnDisabled = false;
        this.submitBtnText = "Submit";
        this._snackBar.open('Some error occurred, please try again', 'Ok', {
          duration: 2000,
          horizontalPosition: this.horizontalPosition,
          verticalPosition: this.verticalPosition,
        });
      }
    );
  }

}
