import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, Validators, NgForm, FormGroupDirective } from '@angular/forms';
import { ApiService } from './../../services/api.service';
import {Router, ActivatedRoute} from '@angular/router';
import {
  MatSnackBar,
  MatSnackBarHorizontalPosition,
  MatSnackBarVerticalPosition,
} from '@angular/material/snack-bar';
@Component({
  selector: 'edit-product',
  templateUrl: './editproduct.component.html',
  styleUrls: ['./editproduct.component.scss']
})
export class EditProductComponent implements OnInit {

  type = "Products";
  title = "Edit";

  formSubmitted = true;

  @ViewChild('servForm', {static: false}) ngForm;

  serviceForm = this.fb.group({
    product_name: ['', Validators.required],
    price: ['', Validators.required],
    quantity: ['', Validators.required]
  });

  horizontalPosition: MatSnackBarHorizontalPosition = 'end';
  verticalPosition: MatSnackBarVerticalPosition = 'top';
  constructor(public fb: FormBuilder, public apiService: ApiService, private router:Router, private route: ActivatedRoute, private _snackBar: MatSnackBar) { }

  ngOnInit() {
    this.apiService.getProductById(this.route.snapshot.params.id).subscribe(res=>{
        this.serviceForm.controls['product_name'].setValue(res['data']['product_name']);
        this.serviceForm.controls['price'].setValue(res['data']['price']);
        this.serviceForm.controls['quantity'].setValue(res['data']['quantity']);
    });
  }

  onSubmit(){
    this.formSubmitted = false;
    if (this.serviceForm.invalid) {
      return;
    }
    this.formSubmitted = true;

    let serviceData = {
        "product_name": this.serviceForm.value['product_name'],
        "price": this.serviceForm.value['price'],
        "quantity": this.serviceForm.value['quantity'],
        "id": this.route.snapshot.params.id
    }
    
    this.apiService.editProduct(serviceData).subscribe(
      (res) => {
        this._snackBar.open(res['message'], 'Ok', {
          duration: 2000,
          horizontalPosition: this.horizontalPosition,
          verticalPosition: this.verticalPosition,
        });
      },
      (err) => {
        this._snackBar.open('Some error occurred, please try again', 'Ok', {
          duration: 2000,
          horizontalPosition: this.horizontalPosition,
          verticalPosition: this.verticalPosition,
        });
      }
    );
  }
}