import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, Validators, NgForm, FormGroupDirective } from '@angular/forms';
import { ApiService } from './../../services/api.service';

import {Router, ActivatedRoute} from '@angular/router';

import {
  MatSnackBar,
  MatSnackBarHorizontalPosition,
  MatSnackBarVerticalPosition,
} from '@angular/material/snack-bar';

@Component({
  selector: 'app-editstaff',
  templateUrl: './editstaff.component.html',
  styleUrls: ['./editstaff.component.scss']
})
export class EditstaffComponent implements OnInit {

  type = "Staffs";
  title = "Edit";

  submitBtnText = "Submit";

  formSubmitted = true;
  isSubmitBtnDisabled = false;
  @ViewChild('staffForm', {static: false}) ngForm;

  signupForm = this.fb.group({
    name: ['', Validators.required],
    address: ['', Validators.required],
    aadhar: ['', [Validators.required, Validators.pattern('[0-9]\\d{11}')]],
    mobile: ['', [Validators.required, Validators.pattern('[5-9]\\d{9}')]]
  });

  horizontalPosition: MatSnackBarHorizontalPosition = 'end';
  verticalPosition: MatSnackBarVerticalPosition = 'top';
  constructor(public fb: FormBuilder, private router:Router, private route: ActivatedRoute, public apiService: ApiService, private _snackBar: MatSnackBar) { }

  ngOnInit() {

    this.apiService.getStaffById(this.route.snapshot.params.id).subscribe(res=>{
      this.signupForm.controls['name'].setValue(res['data']['name']);
      this.signupForm.controls['address'].setValue(res['data']['address']);
      this.signupForm.controls['aadhar'].setValue(res['data']['aadhar']);
      this.signupForm.controls['mobile'].setValue(res['data']['mobile']);
    });
  }

  onSubmit() {
    this.formSubmitted = false;
    if (this.signupForm.invalid) {
      return;
    }
    this.formSubmitted = true;
    this.submitBtnText = 'Submitting, please wait...';
    this.isSubmitBtnDisabled = true;

    let staffData = {
      "name": this.signupForm.value['name'],
      "address": this.signupForm.value['address'],
      "aadhar": this.signupForm.value['aadhar'],
      "mobile": this.signupForm.value['mobile'],
      "id": this.route.snapshot.params.id
    }
    
    this.apiService.editStaff(staffData).subscribe(
      (res) => {
        this.isSubmitBtnDisabled = false;
        this.submitBtnText = "Submit";
        this.ngForm.resetForm();
        this._snackBar.open(res['message'], 'Ok', {
          duration: 2000,
          horizontalPosition: this.horizontalPosition,
          verticalPosition: this.verticalPosition,
        });
        this.router.navigate(['/allstaffs']);
      },
      (err) => {
        this.isSubmitBtnDisabled = false;
        this.submitBtnText = "Submit";
        this._snackBar.open('Some error occurred, please try again', 'Ok', {
          duration: 2000,
          horizontalPosition: this.horizontalPosition,
          verticalPosition: this.verticalPosition,
        });
      }
    );
  }

}
