import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, Validators, NgForm, FormGroupDirective } from '@angular/forms';
import { ApiService } from './../../services/api.service';
import { DatePipe } from '@angular/common';
import {
  MatSnackBar,
  MatSnackBarHorizontalPosition,
  MatSnackBarVerticalPosition,
} from '@angular/material/snack-bar';

@Component({
  selector: 'app-newcustomer',
  templateUrl: './newcustomer.component.html',
  styleUrls: ['./newcustomer.component.scss']
})
export class NewcustomerComponent implements OnInit {

  type = "Customers";
  title = "Add a new customer";

  submitBtnText = "Submit";

  formSubmitted = true;
  isSubmitBtnDisabled = false;
  @ViewChild('customerForm', {static: false}) ngForm;

  signupForm = this.fb.group({
    name: ['', Validators.required],
    email: [''],
    mobile: ['', [Validators.required, Validators.pattern('[6-9]\\d{9}')]],
    birthday: ['']
  });

  horizontalPosition: MatSnackBarHorizontalPosition = 'end';
  verticalPosition: MatSnackBarVerticalPosition = 'top';
  constructor(public fb: FormBuilder, public apiService: ApiService, private _snackBar: MatSnackBar) { }

  ngOnInit() {
  }


  onSubmit() {
    this.formSubmitted = false;
    if (this.signupForm.invalid) {
      return;
    }
    this.formSubmitted = true;
    this.submitBtnText = 'Submitting, please wait...';
    this.isSubmitBtnDisabled = true;

    if(!this.signupForm.value['birthday']){
      this.signupForm.value['birthday'] = "";
    }
    else{
      this.signupForm.value['birthday'] = new DatePipe('en').transform(this.signupForm.value['birthday'], 'yyyy/MM/dd');
    }
    this.apiService.registerCustomer(this.signupForm.value).subscribe(
      (res) => {
        this.isSubmitBtnDisabled = false;
        this.submitBtnText = "Submit";
        this.ngForm.resetForm();
        this._snackBar.open(res['message'], 'Ok', {
          duration: 2000,
          horizontalPosition: this.horizontalPosition,
          verticalPosition: this.verticalPosition,
        });
      },
      (err) => {
        this.isSubmitBtnDisabled = false;
        this.submitBtnText = "Submit";
        this._snackBar.open('Some error occurred, please try again', 'Ok', {
          duration: 2000,
          horizontalPosition: this.horizontalPosition,
          verticalPosition: this.verticalPosition,
        });
      }
    );
  }

}
