import { Component, OnInit, ViewChild } from '@angular/core';
import {MatTableDataSource} from '@angular/material/table';
import { ApiService } from './../../services/api.service';
import {MatPaginator} from '@angular/material/paginator';
import * as _ from "underscore";
import { debounceTime, tap, switchMap, finalize } from "rxjs/operators";

import {
  MatSnackBar,
  MatSnackBarHorizontalPosition,
  MatSnackBarVerticalPosition,
} from '@angular/material/snack-bar';
import { of } from 'rxjs';

export interface PeriodicElement {
  serialno: number;
  services: object;
  totalamount: string;
  created_at:string;
}

@Component({
  selector: 'app-orderhistory',
  templateUrl: './orderhistory.component.html',
  styleUrls: ['./orderhistory.component.scss']
})
export class OrderHistoryComponent implements OnInit {

  type = "Orders";
  title = "history";
  isLoading = false;
  customerMobile:any;
  customers = [];

  horizontalPosition: MatSnackBarHorizontalPosition = 'end';
  verticalPosition: MatSnackBarVerticalPosition = 'top';

  @ViewChild(MatPaginator, {static: false}) paginator: MatPaginator;

  data: PeriodicElement[] = [
    // {serialno: 1, name: 'Kumar Gautam', mobile: 8210907970, email: 'sajal.suraj@gmail.com', birthday:"09/11/2022"},
    // {serialno: 2, name: 'Sajal Suraj', mobile: 8210907970, email: 'abc@gmail.com', birthday:"09/11/2022"}
  ];

  displayedColumns: string[] = ['serialno', 'services', 'totalamount', 'created_at'];
  dataSource;

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  constructor(public apiService:ApiService, private _snackBar: MatSnackBar) { }

  displayFn(val){
    return val && val.mobile ? val.mobile : "";
  }

  ngOnInit() {
    
  }

  searchCustomer(val){
    return of(val).pipe(
      debounceTime(1000), 
      tap(() => {
        this.customers = [];
        this.isLoading = true;
      }),
      switchMap(value =>
        this.apiService
          .searchCustomer({ query: this.customerMobile })
          .pipe(
            finalize(() => {
              this.isLoading = false;
            })
          )
      )
    )
    .subscribe(data => {
      this.customers = data["data"];
    });
  }

  getSelectedCustomer(customer){
    this.apiService.getOrderHisoryByCustomerId(customer.value.id).subscribe(res=>{
      if(res['status']){
        let staffData = res['data'];
        let count = 0;
        staffData.forEach((val)=>{
          count++;
          val.serialno = count;
          if(val.services){
            val.services = JSON.parse(val.services);
          }
          if(val.products){
            val.products = JSON.parse(val.products);
          }
        });
       this.data = staffData;
       this.dataSource = new MatTableDataSource(this.data);
       this.dataSource.paginator = this.paginator;
      }
      else{
        this.dataSource = new MatTableDataSource([]);
        this.dataSource.paginator = this.paginator;
      }
    },
    err=>{

    });
  }

}
