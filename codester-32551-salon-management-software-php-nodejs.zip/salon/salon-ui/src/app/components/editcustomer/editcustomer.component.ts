import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, Validators, NgForm, FormGroupDirective } from '@angular/forms';
import { ApiService } from './../../services/api.service';
import { DatePipe } from '@angular/common';
import {Router, ActivatedRoute} from '@angular/router';
import {
  MatSnackBar,
  MatSnackBarHorizontalPosition,
  MatSnackBarVerticalPosition,
} from '@angular/material/snack-bar';

@Component({
  selector: 'app-editcustomer',
  templateUrl: './editcustomer.component.html',
  styleUrls: ['./editcustomer.component.scss']
})
export class EditcustomerComponent implements OnInit {

  type = "Customers";
  title = "Edit customer";

  submitBtnText = "Submit";

  formSubmitted = true;
  isSubmitBtnDisabled = false;
  @ViewChild('customerForm', {static: false}) ngForm;

  signupForm = this.fb.group({
    name: ['', Validators.required],
    email: [''],
    mobile: ['', [Validators.required, Validators.pattern('[6-9]\\d{9}')]],
    birthday: ['']
  });

  horizontalPosition: MatSnackBarHorizontalPosition = 'end';
  verticalPosition: MatSnackBarVerticalPosition = 'top';
  constructor(public fb: FormBuilder, public apiService: ApiService, private router:Router, private route: ActivatedRoute, private _snackBar: MatSnackBar) { }

  ngOnInit() {

    this.apiService.getCustomerById(this.route.snapshot.params.id).subscribe(res=>{
      let birthday = "";
      if(res['data']['birthday']){
        birthday = res['data']['birthday'].split('/');
        birthday = birthday[0]+'-'+birthday[1]+'-'+birthday[2];
      }
      this.signupForm.controls['name'].setValue(res['data']['name']);
      this.signupForm.controls['email'].setValue(res['data']['email']);
      this.signupForm.controls['mobile'].setValue(res['data']['mobile']);
      this.signupForm.controls['birthday'].setValue(birthday);
      //this.signupForm.setValue(res['data']);
    });
  }


  onSubmit() {
    this.formSubmitted = false;
    if (this.signupForm.invalid) {
      return;
    }
    this.formSubmitted = true;
    this.submitBtnText = 'Submitting, please wait...';
    this.isSubmitBtnDisabled = true;

    if(!this.signupForm.value['birthday']){
      this.signupForm.value['birthday'] = "";
    }
    else{
      this.signupForm.value['birthday'] = new DatePipe('en').transform(this.signupForm.value['birthday'], 'yyyy/MM/dd');
    }

    let customerData = this.signupForm.value;
    customerData['id'] = this.route.snapshot.params.id;
    this.apiService.editCustomer(customerData).subscribe(
      (res) => {
        this.isSubmitBtnDisabled = false;
        this.submitBtnText = "Submit";
        this.ngForm.resetForm();
        this._snackBar.open(res['message'], 'Ok', {
          duration: 2000,
          horizontalPosition: this.horizontalPosition,
          verticalPosition: this.verticalPosition,
        });
        this.router.navigate(['/customers']);
      },
      (err) => {
        this.isSubmitBtnDisabled = false;
        this.submitBtnText = "Submit";
        this._snackBar.open('Some error occurred, please try again', 'Ok', {
          duration: 2000,
          horizontalPosition: this.horizontalPosition,
          verticalPosition: this.verticalPosition,
        });
      }
    );
  }
}
