import { Component, OnInit, ViewChild } from '@angular/core';
import {MatTableDataSource} from '@angular/material/table';
import { ApiService } from './../../services/api.service';
import {MatPaginator} from '@angular/material/paginator';

import {
  MatSnackBar,
  MatSnackBarHorizontalPosition,
  MatSnackBarVerticalPosition,
} from '@angular/material/snack-bar';

export interface PeriodicElement {
  serialno: number,
  name: string;
  price: number;
  action:any
}

@Component({
  selector: 'app-services',
  templateUrl: './services.component.html',
  styleUrls: ['./services.component.scss']
})
export class ServicesComponent implements OnInit {

  type = "Services";
  title = "List";

  horizontalPosition: MatSnackBarHorizontalPosition = 'end';
  verticalPosition: MatSnackBarVerticalPosition = 'top';

  @ViewChild(MatPaginator, {static: false}) paginator: MatPaginator;

  data: PeriodicElement[] = [
    // {serialno: 1, name: 'Kumar Gautam', price: 8210907970},
    // {serialno: 2, name: 'Sajal Suraj', price: 8210907970}
  ];

  displayedColumns: string[] = ['serialno', 'name', 'price', 'action'];
  dataSource;

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  constructor(public apiService: ApiService, private _snackBar: MatSnackBar) { }

  ngOnInit() {
    let staffData = [];
    this.apiService.getAllServices().subscribe(res=>{
      if(res['status']){
        staffData = res['data'];
        let count = 0;
        staffData.forEach((val)=>{
          count++;
          val.serialno = count;
        });
       this.data = staffData;
       this.dataSource = new MatTableDataSource(this.data);
       this.dataSource.paginator = this.paginator;
      }
    },
    err=>{

    });
  }

  deleteService(id, name){
    if(confirm("Do you want to delete this service")) {
      this.apiService.deleteService(id).subscribe((res)=>{
        this._snackBar.open(res['message'], 'Ok', {
          duration: 2000,
          horizontalPosition: this.horizontalPosition,
          verticalPosition: this.verticalPosition,
        });
        let staffData = [];
        this.apiService.getAllServices().subscribe(res=>{
          if(res['status']){
            staffData = res['data'];
            let count = 0;
            staffData.forEach((val)=>{
              count++;
              val.serialno = count;
            });
          this.data = staffData;
          this.dataSource = new MatTableDataSource(this.data);
          this.dataSource.paginator = this.paginator;
          }
        },
        err=>{

        });
      });
    }
  }

}
