const { app, BrowserWindow, ipcMain } = require("electron");
const path = require("path");
const url = require("url");

let win;

function createWindow(){
    win = new BrowserWindow({
        width: 1000,
        height:600,
        webPreferences: { 
          nodeIntegration: true
        } 
    });

    // workerWindow = new BrowserWindow({
    //   parent: win,
    //   webPreferences: {
    //     nodeIntegration: true
    //   },
    // });
    // workerWindow.loadURL(
    //   url.format({
    //     pathname: path.join(__dirname, `/dist/salon/index.html#/printtable`),
    //     protocol: "file:",
    //     slashes: true
    //   })
    // );
    // workerWindow.hide();

    // load the dist folder from Angular
    win.loadURL(
        url.format({
        pathname: path.join(__dirname, `/dist/salon/index.html`),
        protocol: "file:",
        slashes: true
        })
    );

    //win.webContents.openDevTools();

    // win.webContents.executeJavaScript(
    //   console.log(document.getElementById('ticket'))
    // )

    //win.setFullScreen(true);
    win.show();

    // The following is optional and will open the DevTools:
    // win.webContents.openDevTools()

    win.on("closed", () => {
        win = null;
    });
}


app.on("ready", createWindow);

// on macOS, closing the window doesn't quit the app
app.on("window-all-closed", () => {
  if (process.platform !== "darwin") {
    app.quit();
  }
});

// ipcMain.on('ping', (event, arg) => {
//   //workerWindow.webContents.send("printData", arg);
//   workerWindow.webContents.print();
// })

// ipcMain.on("readyToPrintPDF", (event) => {
//   // Use default printing options
//   workerWindow.webContents.print();
// });

// initialize the app's main window
app.on("activate", () => {
  if (win === null) {
    createWindow();
  }
});